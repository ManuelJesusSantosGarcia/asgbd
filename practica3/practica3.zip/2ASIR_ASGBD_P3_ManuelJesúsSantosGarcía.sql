-- Comando SQL: Gestión de Usuarios y Credenciales

-- Usar la BBDD especifica
USE tienda_informatica;

-- 1.Creación de usuarios con su correspondiente origen (host) y contraseña cifrada
CREATE USER IF NOT EXISTS 'administrador'@'localhost' IDENTIFIED BY 'Admin2026!';
CREATE USER IF NOT EXISTS 'soporte'@'%' IDENTIFIED BY 'cuentasoporte';

-- 2.Modificación de credenciales y bloqueo de cuenta (Demostración de ALTER USER)
ALTER USER 'soporte'@'%' IDENTIFIED BY 'NuevaClaveSoporte#2026';
ALTER USER 'soporte'@'%' ACCOUNT LOCK;
ALTER USER 'soporte'@'%' ACCOUNT UNLOCK;
ALTER USER 'administrador'@'localhost' ACCOUNT UNLOCK;

-- 3.Muestra las cuentas creadas y su estado de bloqueo
SELECT User, Host, account_locked
FROM mysql.user
WHERE User IN ('administrador', 'soporte');

-- Comando SQL: Concesión de Privilegios

-- 1.Permiso de solo lectura en una tabla específica
GRANT SELECT ON tienda_informatica.articulos TO 'soporte'@'%';

-- 2.Permisos DML múltiples a nivel de toda la base de datos
GRANT SELECT, INSERT, UPDATE ON tienda_informatica.* TO 'administrador'@'localhost';

-- 3.Refrescar la memoria interna de privilegios
FLUSH PRIVILEGES;

-- 4.Muestra concesion de permiso para toda la base de datos
SHOW GRANTS FOR 'soporte'@'%';
SHOW GRANTS FOR 'administrador'@'localhost';

-- Comando SQL: Auditoría, Revocación y Borrado

-- 1. Consultar los privilegios asignados a las cuentas

-- 2. Retirar un privilegio específico
REVOKE SELECT ON tienda_informatica.articulos FROM 'soporte'@'%';

-- 3. Eliminar usuario indicando correctamente usuario y host en el caso de que procediera
DROP USER IF EXISTS 'administrador'@'localhost';
SHOW GRANTS FOR 'soporte'@'%';

-- 4. Retirar un privilegio específico
REVOKE SELECT ON tienda_informatica.articulos FROM 'soporte'@'%';

-- 5. Eliminar usuario indicando correctamente usuario y host
DROP USER IF EXISTS 'administrador'@'localhost';

-- 6. Muestra privilegio SELECT ya no aparece listado para el usuario soporte
SHOW GRANTS FOR 'soporte'@'%';

-- Comando SQL: Gestión de Roles (Agrupación de Privilegios)

-- 1. Crear el rol de seguridad
CREATE ROLE IF NOT EXISTS 'rol_analista';

-- 2. Asignar privilegios al rol
GRANT SELECT ON tienda_informatica.* TO 'rol_analista';

-- 3. Asignar el rol al usuario y activarlo como rol por defecto
GRANT 'rol_analista' TO 'soporte'@'%';
SET DEFAULT ROLE 'rol_analista' TO 'soporte'@'%';

-- Comando SQL: Creación roles según permisos
SHOW GRANTS FOR 'rol_analista';
SHOW GRANTS FOR 'soporte'@'%';

-- Comando SQL: Creación de Vistas y Permisos Asociados

-- 1. Crear una vista que limite la exposición de columnas o filas sensibles
CREATE OR REPLACE VIEW v_articulos_publico AS
SELECT id, nombre, precio 
FROM tienda_informatica.articulos;

-- 2. Otorgar permisos de consulta únicamente sobre la vista segura
GRANT SELECT ON tienda_informatica.v_articulos_publico TO 'soporte'@'%';

-- Refresco final de la tabla de privilegios
FLUSH PRIVILEGES;

-- Muestra datos que devuelve la vista segura
SELECT * FROM tienda_informatica.v_articulos_publico;

-- Muestra usuario tiene permiso concedido sobre la vista
SHOW GRANTS FOR 'soporte'@'%';


